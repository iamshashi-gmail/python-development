# Change Log

## [1.0.1] 2021-04-13
### Improvements

- UI: [Jinja Black PRO](https://github.com/app-generator/jinja-black-dashboard-pro) v1.0.2
- Codebase: [Django Dashboard](https://github.com/app-generator/boilerplate-code-django-dashboard) v1.0.4

## [1.0.0] 2020-07-22
### Initial Release

- UI Kit version - v1.1.1
- [Codebase](https://github.com/app-generator/boilerplate-code-django-dashboard) version - v1.0.2
